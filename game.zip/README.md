# Loup Solitaire - Version Ren'Py

Conversion du livre dont vous êtes le héros "Loup Solitaire" en jeu Ren'Py interactif.

## Installation

1. Installer Ren'Py depuis https://www.renpy.org/
2. Copier ce dossier dans le répertoire des projets Ren'Py
3. Lancer Ren'Py et ouvrir le projet

## Conversion des fichiers HTML

Pour convertir automatiquement les fichiers HTML en scripts Ren'Py :

```bash
python convertir_html.py
```

Ce script va :
- Parser tous les fichiers HTML des tomes 1-5
- Extraire le texte, les choix et les conditions
- Générer les fichiers `.rpy` correspondants

## Structure du projet

- `game/` : Fichiers du jeu Ren'Py
  - `options.rpy` : Configuration du jeu
  - `personnage.rpy` : Système de gestion du personnage
  - `combat.rpy` : Système de combat avec dés virtuels
  - `interface.rpy` : Écrans d'interface (feuille d'aventure, sauvegarde)
  - `script.rpy` : Script principal
  - `tome*_sections.rpy` : Sections converties (générées automatiquement)

## Fonctionnalités

- ✅ Système de personnage complet (stats, disciplines, objets)
- ✅ Système de combat avec dés virtuels
- ✅ Navigation entre sections
- ✅ Vérification des conditions (disciplines, rang)
- ✅ Sauvegarde/Chargement
- ✅ Feuille d'aventure interactive

## À faire

- [ ] Conversion complète de tous les tomes
- [ ] Gestion des images
- [ ] Interface graphique améliorée
- [ ] Sons et musiques
- [ ] Animations des dés

## Notes

Le projet original utilise ActiveX et nécessite Internet Explorer. Cette version Ren'Py est multiplateforme et moderne.

