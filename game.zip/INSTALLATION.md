# Guide d'Installation et d'Utilisation

## Prérequis

1. **Ren'Py** (version 7.4 ou supérieure)
   - Télécharger depuis https://www.renpy.org/
   - Installer selon votre système d'exploitation

2. **Python 3** (pour le script de conversion)
   - Python 3.7 ou supérieur
   - Installer BeautifulSoup4 : `pip install beautifulsoup4 lxml`

## Installation du projet

1. **Copier le projet**
   - Copier le dossier `loup_solitaire_renpy` dans votre répertoire de projets Ren'Py
   - Par défaut : `~/renpy/games/` (Linux/Mac) ou `C:\Users\VotreNom\renpy\games\` (Windows)

2. **Copier les images** (optionnel mais recommandé)
   - Copier le dossier `images` depuis `LS-I T1 - T5/images/` vers `loup_solitaire_renpy/game/images/`
   - Ou créer des images de remplacement

3. **Convertir les fichiers HTML**
   ```bash
   cd loup_solitaire_renpy
   python convertir_html.py
   ```
   Cela va générer les fichiers `tome1_sections.rpy`, `tome2_sections.rpy`, etc.

## Lancement du jeu

1. Ouvrir Ren'Py Launcher
2. Sélectionner "Loup Solitaire" dans la liste des projets
3. Cliquer sur "Launch Project"

## Utilisation

### Création de personnage
- Au démarrage, lancez les dés pour déterminer vos stats
- Choisissez 5 disciplines Kai parmi les 10 disponibles

### Navigation
- Les choix sont présentés sous forme de menu
- Certains choix nécessitent des disciplines ou un rang spécifique
- Utilisez la feuille d'aventure pour gérer vos stats et objets

### Combat
- Les combats utilisent un système de dés virtuels (0-9)
- Cliquez sur "Lancer le dé et combattre" pour chaque round
- Le résultat du dé et les dégâts sont calculés automatiquement

### Sauvegarde
- Accédez à la sauvegarde depuis le menu ou la feuille d'aventure
- 3 emplacements de sauvegarde disponibles
- Les sauvegardes sont automatiques à chaque changement de section

## Structure des fichiers

- `game/options.rpy` : Configuration de base
- `game/personnage.rpy` : Système de personnage
- `game/combat.rpy` : Système de combat avec dés
- `game/interface.rpy` : Écrans d'interface
- `game/script.rpy` : Script principal et sections de base
- `game/tome*_sections.rpy` : Sections converties (générées)

## Personnalisation

### Modifier les couleurs
Éditez `game/gui.rpy` pour changer les couleurs de l'interface.

### Ajouter des images
Placez les images dans `game/images/` et référencez-les dans les scripts.

### Modifier les règles
Éditez `game/personnage.rpy` et `game/combat.rpy` pour ajuster les règles du jeu.

## Dépannage

### Le jeu ne démarre pas
- Vérifiez que Ren'Py est à jour
- Vérifiez les erreurs dans la console Ren'Py (Shift+O)

### Les images ne s'affichent pas
- Vérifiez que les images sont dans `game/images/`
- Vérifiez les chemins dans `game/gui.rpy`

### Erreurs de conversion HTML
- Installez BeautifulSoup4 : `pip install beautifulsoup4 lxml`
- Vérifiez que les fichiers HTML sont accessibles

## Support

Pour toute question ou problème, consultez :
- La documentation Ren'Py : https://www.renpy.org/doc/html/
- Le README.md du projet

