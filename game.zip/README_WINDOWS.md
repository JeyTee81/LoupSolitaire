# Guide Windows - Installation des dépendances

## Problème : 'pip' n'est pas reconnu

Sur Windows, il faut utiliser `python -m pip` ou `py -m pip` au lieu de `pip` directement.

## Solutions

### Solution 1 : Utiliser le script batch (RECOMMANDÉ)

Double-cliquez sur `install_dependencies.bat` dans le dossier du projet.

Ce script essaie automatiquement les différentes commandes Python disponibles.

### Solution 2 : Utiliser python -m pip

Ouvrez PowerShell ou Invite de commandes et tapez :

```cmd
python -m pip install beautifulsoup4 lxml
```

Si ça ne fonctionne pas, essayez :

```cmd
py -m pip install beautifulsoup4 lxml
```

### Solution 3 : Utiliser la version simplifiée (SANS dépendances)

Si vous ne pouvez pas installer BeautifulSoup4, utilisez la version simplifiée du script :

```cmd
python convertir_html_simple.py
```

ou

```cmd
py convertir_html_simple.py
```

Cette version n'utilise que des expressions régulières et ne nécessite aucune dépendance externe.

## Vérifier que Python est installé

1. Ouvrez PowerShell ou Invite de commandes
2. Tapez : `python --version` ou `py --version`
3. Si vous obtenez une erreur, installez Python depuis https://www.python.org/
   - **IMPORTANT** : Cochez "Add Python to PATH" lors de l'installation

## Après l'installation

Une fois les dépendances installées (ou si vous utilisez la version simplifiée), lancez la conversion :

```cmd
python convertir_html.py
```

ou (version simplifiée) :

```cmd
python convertir_html_simple.py
```

## Dépannage

### "python n'est pas reconnu"
- Installez Python depuis https://www.python.org/
- Cochez "Add Python to PATH" lors de l'installation
- Redémarrez votre terminal après l'installation

### "py n'est pas reconnu"
- Utilisez `python` au lieu de `py`
- Ou installez Python depuis le Microsoft Store

### Erreurs de permissions
- Exécutez PowerShell en tant qu'administrateur
- Ou utilisez : `python -m pip install --user beautifulsoup4 lxml`

