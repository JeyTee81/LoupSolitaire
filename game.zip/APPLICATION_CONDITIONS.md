# Application des conditions aux sections Ren'Py

## Résumé de l'analyse

L'analyse des fichiers HTML a identifié **234 sections avec conditions** et **253 choix conditionnels** à travers les 5 tomes :

- **Tome 1** : 31 sections, 32 choix conditionnels
- **Tome 2** : 34 sections, 35 choix conditionnels  
- **Tome 3** : 58 sections, 64 choix conditionnels
- **Tome 4** : 49 sections, 56 choix conditionnels
- **Tome 5** : 62 sections, 66 choix conditionnels

## Types de conditions identifiées

1. **Disciplines Kai** (0-9) : Le joueur doit posséder une ou plusieurs disciplines
   - Exemple : `personnage.has_discipline(2)` pour le Sixième Sens
   - Conditions multiples : `(personnage.has_discipline(1) or personnage.has_discipline(2))`

2. **Rang Kai** : Le joueur doit avoir atteint un certain rang
   - Exemple : `personnage.has_rang(7)` pour le rang de Gardien

3. **Objets** : Le joueur doit posséder certains objets
   - Glaive de Sommer : `personnage.glaive_sommer >= 0`
   - Épée du Capitaine Gayal : `"Épée du Capitaine Gayal" in personnage.objets_speciaux`

## Modifications apportées

Le script `appliquer_conditions.py` modifie les menus Ren'Py pour ajouter les conditions :

**Avant :**
```renpy
menu:
    "Si vous souhaitez utiliser votre Maîtrise du Sixième Sens rendez-vous au 141.":
        jump tome1_sect141
```

**Après :**
```renpy
menu:
    "Si vous souhaitez utiliser votre Maîtrise du Sixième Sens rendez-vous au 141." if personnage.has_discipline(2):
        jump tome1_sect141
```

## Fichiers modifiés

- `game/tome1_sections.rpy` → Backup : `tome1_sections.rpy.bak_conditions`
- `game/tome2_sections.rpy` → Backup : `tome2_sections.rpy.bak_conditions`
- `game/tome3_sections.rpy` → Backup : `tome3_sections.rpy.bak_conditions`
- `game/tome4_sections.rpy` → Backup : `tome4_sections.rpy.bak_conditions`
- `game/tome5_sections.rpy` → Backup : `tome5_sections.rpy.bak_conditions`

## Exécution

Pour appliquer les conditions à tous les tomes :

```bash
python appliquer_conditions.py
```

## Vérification

Après l'application, vérifier que :
1. Les fichiers de backup ont été créés
2. Les sections modifiées sont correctes
3. Le jeu compile sans erreurs dans Ren'Py
4. Les choix conditionnels ne s'affichent que si les conditions sont remplies

## Prochaines étapes

1. ✅ Analyse des conditions terminée
2. ✅ Script d'application créé et testé
3. ⏳ Application à tous les tomes
4. ⏳ Tests dans Ren'Py
5. ⏳ Vérification des sections avec redirections automatiques


