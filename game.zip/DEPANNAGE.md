# Guide de dépannage - Problème de navigation

## Problème : "Je reviens toujours au premier texte après un choix"

### Solutions à essayer dans l'ordre :

#### 1. Forcer une recompilation complète dans Ren'Py
1. Ouvrez Ren'Py
2. Sélectionnez votre projet "Loup Solitaire"
3. Cliquez sur **"Force Recompile"** dans le menu (ou appuyez sur Shift+R)
4. Attendez que la compilation se termine
5. Relancez le jeu

#### 2. Vérifier les erreurs de compilation
1. Dans Ren'Py, ouvrez le projet
2. Cliquez sur **"Check Script"** (ou appuyez sur Shift+L)
3. Vérifiez s'il y a des erreurs ou des avertissements
4. Si des erreurs apparaissent, notez-les et corrigez-les

#### 3. Nettoyer manuellement le cache
1. Fermez Ren'Py complètement
2. Supprimez le dossier `game/cache/` s'il existe
3. Supprimez tous les fichiers `.rpyc` dans `game/` et ses sous-dossiers
4. Rouvrez Ren'Py et forcez la recompilation

#### 4. Vérifier la console Ren'Py
1. Dans Ren'Py, ouvrez le projet
2. Lancez le jeu
3. Ouvrez la console (Shift+O ou clic droit > Console)
4. Faites un choix dans le jeu
5. Regardez s'il y a des messages d'erreur dans la console

#### 5. Tester avec un label simple
Si le problème persiste, testez avec un label minimal pour isoler le problème.

### Vérifications effectuées
- ✓ Tous les labels référencés existent
- ✓ La syntaxe des menus est correcte
- ✓ Les jumps sont correctement formés
- ✓ Le cache a été nettoyé

### Si le problème persiste
1. Vérifiez la version de Ren'Py (doit être 8.0 ou supérieur)
2. Essayez de créer un nouveau projet Ren'Py et copiez les fichiers
3. Vérifiez les permissions d'écriture sur le dossier `game/`

