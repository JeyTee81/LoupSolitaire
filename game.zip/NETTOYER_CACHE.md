# Nettoyer le cache Ren'Py

Si vous avez des erreurs liées à des fichiers supprimés, vous devez nettoyer le cache de Ren'Py.

## Méthode 1 : Via Ren'Py Launcher

1. Ouvrez Ren'Py Launcher
2. Sélectionnez le projet "Loup Solitaire"
3. Cliquez sur "Delete Persistent" (supprime les données persistantes)
4. Cliquez sur "Force Recompile" (force la recompilation)

## Méthode 2 : Supprimer manuellement

Supprimez les dossiers suivants dans `loup_solitaire_renpy/game/` :
- `cache/` (dossier de cache)
- Tous les fichiers `.rpyc` (fichiers compilés)

Ou utilisez le script `nettoyer_cache.bat`

